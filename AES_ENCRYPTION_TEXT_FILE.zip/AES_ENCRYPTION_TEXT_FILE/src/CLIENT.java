import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JFormattedTextField;
import java.awt.BorderLayout;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JProgressBar;
import javax.swing.JFileChooser;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.awt.TextField;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.Color;

public class CLIENT {

	JFrame frame;
	String key = "Mary has one cat";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		 
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AES_APPLICATION_WINDOW window = new AES_APPLICATION_WINDOW();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @wbp.parser.entryPoint
	 */
	public CLIENT() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("AES_ENCRYPTION_DECRYPTION_TEXT_FILE CLIENT");
		frame.setBackground(Color.WHITE);
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblFileEncryptionAnd = new JLabel("FILE ENCRYPTION AND DECRYPTION IN AES");
		lblFileEncryptionAnd.setBounds(33, 11, 234, 14);
		frame.getContentPane().add(lblFileEncryptionAnd);
		
		TextField textField_1 = new TextField();
		textField_1.setBounds(182, 36, 164, 22);
		frame.getContentPane().add(textField_1);
		
		Label label = new Label("ENTER IP ADDRESS TO CONNECT");
		label.setBounds(10, 36, 234, 22);
		frame.getContentPane().add(label);
		
		JButton btnSendEncryptedFile = new JButton("RECEIVE ENCRYPTED  FILE AND DECRYPT CONTENT BELOW");
		btnSendEncryptedFile.setBounds(46, 64, 350, 23);
		frame.getContentPane().add(btnSendEncryptedFile);
		
		TextArea textArea = new TextArea();
		textArea.setBounds(32, 101, 380, 150);
		frame.getContentPane().add(textArea);
		
	}
}
