import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.awt.Label;
import java.net.*; 
import java.io.*; 
public class LALITH {

	private JFrame frame;
	private JTextField textField;
private TextArea textArea;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LALITH window = new LALITH();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LALITH() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize() {
		frame = new JFrame();
		frame.setAutoRequestFocus(false);
		frame.setBounds(100, 100, 686, 392);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(71, 35, 188, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("CONNECT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StartClientActionPerformed(arg0);
				
			}
		});
		btnNewButton.setBounds(276, 34, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblIpAddress = new JLabel("IP ADDRESS");
		lblIpAddress.setBounds(10, 38, 89, 14);
		frame.getContentPane().add(lblIpAddress);
		
		JButton btnReceiveDecryptedText = new JButton("RECEIVE DECRYPTED TEXT");
		btnReceiveDecryptedText.setBounds(81, 76, 193, 23);
		frame.getContentPane().add(btnReceiveDecryptedText);
		
		textArea = new TextArea();
		textArea.setBounds(24, 111, 618, 208);
		frame.getContentPane().add(textArea);
		
		Label label = new Label("CLIENT ");
		label.setBounds(10, 10, 62, 22);
		frame.getContentPane().add(label);
	}
	 private void StartClientActionPerformed(java.awt.event.ActionEvent evt) {
		 new Thread(new Runnable() {
	            @Override
	            public void run() {
	            	try{      
	            		Socket s=new Socket(textField.getText(),6666);  
	            		DataInputStream dis=new DataInputStream(s.getInputStream());  
	            		String  str=(String)dis.readUTF();  
	            		System.out.println(str);
	            		textArea.setText(str);
	            		s.close();  
	            		}catch(Exception e){System.out.println(e);}  
	 }
	            }).start();
}
}
