import java.awt.EventQueue;
import java.net.*; 
import java.io.*; 

import javax.swing.JFrame;
import javax.swing.JFormattedTextField;
import java.awt.BorderLayout;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JProgressBar;
import javax.swing.JFileChooser;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.awt.TextField;
import java.awt.Label;
import java.awt.Button;

public class AES_APPLICATION_WINDOW {

	JFrame frame;
	private JTextField textField;
	
	String key = "Mary has one cat";
	String a="";
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		 
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AES_APPLICATION_WINDOW window = new AES_APPLICATION_WINDOW();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AES_APPLICATION_WINDOW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize() {
		frame = new JFrame("AES_ENCRYPTION_DECRYPTION_TEXT_FILE");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblFileEncryptionAnd = new JLabel("FILE ENCRYPTION AND DECRYPTION IN AES");
		lblFileEncryptionAnd.setBounds(121, 11, 234, 14);
		frame.getContentPane().add(lblFileEncryptionAnd);
		
		JLabel lblAddYourText = new JLabel("Server Add File to Encrypt and send");
		lblAddYourText.setBounds(69, 108, 208, 14);
		frame.getContentPane().add(lblAddYourText);
		
		JButton StartServer = new JButton("START SERVER");
		StartServer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StartServerActionPerformed(arg0);
				
			}
		});
		StartServer.setBounds(151, 56, 131, 23);
		frame.getContentPane().add(StartServer);
		
		textField = new JTextField();
		textField.setBounds(69, 133, 220, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton btnBrowse = new JButton("BROWSE");
		btnBrowse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 JFileChooser chooser = new JFileChooser();
			        chooser.showOpenDialog(null);
			        File f = chooser.getSelectedFile();
			        textField.setText(f.getAbsolutePath());
			}
		});
		btnBrowse.setBounds(307, 132, 89, 23);
		frame.getContentPane().add(btnBrowse);
		
		JButton btnSendEncryptedFile = new JButton("SEND ENCRYPTED  FILE TO CLIENT");
		btnSendEncryptedFile.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					a="dddddd";
				}
				}); 
			
		btnSendEncryptedFile.setBounds(96, 175, 208, 23);
		frame.getContentPane().add(btnSendEncryptedFile);
		
	}
	 private void StartServerActionPerformed(java.awt.event.ActionEvent evt) {
		 new Thread(new Runnable() {
	            @Override
	            public void run() {
	                try {
	                		ServerSocket ss=new ServerSocket(6666);  
	                		Socket s=ss.accept();//establishes connection    
	                		DataOutputStream dout=new DataOutputStream(s.getOutputStream()); 
	                			dout.writeUTF(a);  
	                			System.out.println(a);
	                			
	                		
	                		dout.flush();  
	                		dout.close();  
	                		s.close();  
	                	}
	                catch(Exception e){System.out.println(e);}
	 }
	            }).start();
}
}
