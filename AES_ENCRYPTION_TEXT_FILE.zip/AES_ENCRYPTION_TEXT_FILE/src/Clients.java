import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextPane;
import javax.swing.JTextArea;

public class Clients {

	private JFrame frame;
	private JTextField textField;
    DataInputStream dis;
    String a="C:\\Users\\lenovo\\Desktop\\dec.txt";
    String b="C:\\Users\\lenovo\\Desktop\\decrypted.txt";
    private JTextField textField_1;
    String key="";
    JTextArea textArea;
	/**"
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Clients window = new Clients();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Clients() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 636, 363);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(91, 47, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblDecryptionOfFile = new JLabel("Decryption of file from server");
		lblDecryptionOfFile.setBounds(66, 11, 217, 14);
		frame.getContentPane().add(lblDecryptionOfFile);
		
		JLabel lblIpAddress = new JLabel("IP ADDRESS");
		lblIpAddress.setBounds(10, 50, 71, 14);
		frame.getContentPane().add(lblIpAddress);
		
		JButton btnConnect = new JButton("CONNECT");
		btnConnect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				sendClientActionPerformed(arg0);
				
			}
		});
		btnConnect.setBounds(202, 46, 89, 23);
		frame.getContentPane().add(btnConnect);
		
		JLabel lblReceived = new JLabel("RECEIVED FILE :");
		lblReceived.setBounds(10, 78, 121, 14);
		frame.getContentPane().add(lblReceived);
		
		textField_1 = new JTextField();
		textField_1.setBounds(91, 75, 86, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnDecryptMessage = new JButton("DECRYPT MESSAGE");
		btnDecryptMessage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 File decryptedFile = new File(b);
				 File inputFile = new File("C:\\Users\\lenovo\\Desktop\\document.txt");
			        try {
			        	//Aes_enc_dec.encrypt(key, inputFile, encryptedFile);
			        	Aes_enc_dec.decrypt(key, inputFile, decryptedFile);
			        } catch (CryptoException ex) {
			            System.out.println(ex.getMessage());
			            ex.printStackTrace();
			        }
			}
		});
		btnDecryptMessage.setBounds(202, 81, 155, 23);
		frame.getContentPane().add(btnDecryptMessage);
		
		textArea = new JTextArea();
		textArea.setBounds(10, 113, 495, 200);
		frame.getContentPane().add(textArea);
		
		JButton btnReadText = new JButton("read text");
		btnReadText.addActionListener( new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
            	 setShowText(b);
        }});
		btnReadText.setBounds(515, 114, 89, 23);
		frame.getContentPane().add(btnReadText);
	}
	 private void sendClientActionPerformed(java.awt.event.ActionEvent evt) {
		 new Thread(new Runnable() {
	            @Override
	            public void run() {
	                try {
	                	Socket s=new Socket((String)textField.getText(),6666);  
	                	dis=new DataInputStream(s.getInputStream());
	                	DataOutputStream dout=new DataOutputStream(s.getOutputStream());  
	                	dout.writeUTF("client connected");  
	                	String  str=(String)dis.readUTF();  
	                	System.out.println("message= "+str);  
	                	textField_1.setText(str);
	                	key=(String)dis.readUTF(); 
	                	System.out.println(key);
	                	saveFile(a);
	                	
	                	s.close();  
	                	}catch(Exception e){System.out.println(e);}   
	 }
	            }).start();
}
	 private void saveFile(String s) throws IOException {
			
			FileOutputStream fos = new FileOutputStream(s);
			byte[] buffer = new byte[4096];
			
			int filesize = 15123; // Send file size in separate msg
			int read = 0;
			int totalRead = 0;
			int remaining = filesize;
			while((read = dis.read(buffer, 0, Math.min(buffer.length, remaining))) > 0) {
				totalRead += read;
				remaining -= read;
				System.out.println("read " + totalRead + " bytes.");
				fos.write(buffer, 0, read);
			}
			
			fos.close();
			dis.close();
		}
	 public void setShowText(String a){
	       try{
	    	   FileReader fr = new FileReader(a);
	    	   BufferedReader br = new BufferedReader(fr);
	    	   String s;
	    	   while((s=br.readLine())!=null)
	    	   {
	    	   textArea.append(s + "\n");
	    	   }
	    	   fr.close();
	    	   }
	    	   catch(Exception ae)
	    	   {
	    	   System.out.println(ae);
	    	   }
	        }
}

