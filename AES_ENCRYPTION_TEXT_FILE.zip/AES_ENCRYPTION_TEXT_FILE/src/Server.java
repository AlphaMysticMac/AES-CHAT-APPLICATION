import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JTextField;

public class Server {

	private JFrame frame;
	private JTextField textField;
	ServerSocket ss;
	Socket s; 
	DataInputStream dis;
	JButton Send ;
	DataOutputStream dout;
	private JLabel lblClient;
	public  String line="";
	public String key="";
	private JTextField textField_1;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Server window = new Server();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Server() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblEncryptedFileTransfer = new JLabel("ENCRYPTED FILE TRANSFER: SERVER ");
		lblEncryptedFileTransfer.setBounds(81, 21, 257, 14);
		frame.getContentPane().add(lblEncryptedFileTransfer);
		
		JButton StartServer_And_Send_File = new JButton("START SERVER AND SEND FILE");
		StartServer_And_Send_File.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ServerActionPerformed(arg0);
				
			}
		});
		StartServer_And_Send_File.setBounds(38, 210, 226, 23);
		frame.getContentPane().add(StartServer_And_Send_File);
		
		textField = new JTextField();
		textField.setBounds(10, 116, 254, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		Send = new JButton("SET FILE PATH");
		Send.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					 JFileChooser chooser = new JFileChooser();
				        chooser.showOpenDialog(null);
				        File f = chooser.getSelectedFile();
				        textField.setText(f.getAbsolutePath());
                	
                	
					
	}});
		Send.setBounds(271, 115, 125, 23);
		frame.getContentPane().add(Send);
		
		lblClient = new JLabel("client:");
		lblClient.setBounds(293, 212, 118, 19);
		frame.getContentPane().add(lblClient);
		
		JButton btnEncryptFile = new JButton("ENCRYPT FILE ");
		btnEncryptFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 File inputFile = new File(textField.getText());
			     File encryptedFile = new File("C:\\Users\\lenovo\\Desktop\\document.txt");
			     try {
			        	Aes_enc_dec.encrypt(key, inputFile, encryptedFile);
			        	line="C:\\Users\\lenovo\\Desktop\\document.txt";
			        } catch (CryptoException ex) {
			            System.out.println(ex.getMessage());
			            ex.printStackTrace();
			        }
			        
			}
		});
		btnEncryptFile.setBounds(90, 147, 134, 23);
		frame.getContentPane().add(btnEncryptFile);
		
		textField_1 = new JTextField();
		textField_1.setBounds(10, 68, 254, 20);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnSetRsaKey = new JButton("SET KEY");
		btnSetRsaKey.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				key= textField_1.getText();
            	
				
}});
		btnSetRsaKey.setBounds(278, 67, 118, 23);
		frame.getContentPane().add(btnSetRsaKey);
	}
	 private void ServerActionPerformed(java.awt.event.ActionEvent evt) {
		 new Thread(new Runnable() {
	            @Override
	            public void run() {
	                try {
	                	ss=new ServerSocket(6666);  
	                	s=ss.accept();//establishes connection   
	                	dis=new DataInputStream(s.getInputStream());  
	                	//FileInputStream file = new FileInputStream("");
	                	String  str=(String)dis.readUTF();  
	                	lblClient.setText(str);
	                	dout=new DataOutputStream(s.getOutputStream());  
	                    dout.writeUTF(line);
	                    dout.writeUTF(key);
	                	sendFile(line);
	                    
	            		}
	            	
	                
	                	catch(Exception e){System.out.println(e);}  
	 }
	            }).start();
}
	 public void sendFile(String file) throws IOException {
			//dout = new DataOutputStream(s.getOutputStream());
			FileInputStream fis = new FileInputStream(file);
			byte[] buffer = new byte[4096];
			
			while (fis.read(buffer) > 0) {
				dout.write(buffer);
			}
			
			fis.close();
			dout.close();	
		}
}	


