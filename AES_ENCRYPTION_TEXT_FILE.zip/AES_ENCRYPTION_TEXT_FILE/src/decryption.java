
 
import java.io.File;
 
/**
 * A tester for the CryptoUtils class.
 * @author www.codejava.net
 *
 */
public class decryption {
    public static void main(String[] args) {
        String key = "Mary has one cat";
        File inputFile = new File("document.txt");
        File encryptedFile = new File("C:\\Users\\lenovo\\Desktop\\dec.txt");
        File decryptedFile = new File("C:\\Users\\lenovo\\Desktop\\decrypted.txt");
         
        try {
           
        	Aes_enc_dec.decrypt(key, encryptedFile, decryptedFile);
        } catch (CryptoException ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
        }
    }
}