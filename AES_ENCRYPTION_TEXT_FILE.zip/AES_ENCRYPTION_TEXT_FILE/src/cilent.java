import java.io.*;  
import java.net.*;  
public class cilent {  
public static void main(String[] args) {  
try{      
Socket s=new Socket("192.168.1.3",6666);  
DataInputStream dis=new DataInputStream(s.getInputStream());  
String  str=(String)dis.readUTF();  
System.out.println("message= "+str);  
s.close();  
}catch(Exception e){System.out.println(e);}  
}  
}  